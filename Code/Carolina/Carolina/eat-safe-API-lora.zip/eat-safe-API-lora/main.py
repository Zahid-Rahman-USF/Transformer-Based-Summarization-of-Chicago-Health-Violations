"""
Eat Safe API - Flask App Entry Point
Initializes the Flask app, registers routes, and starts the server.
"""
from flask import Flask
from flask_cors import CORS
from app.routes import bp as routes_bp
from app.utils.logger import logger
 
 
def create_app():
    """
    Create and configure the Flask app.
    Returns:
        Flask: The configured Flask app instance.
    """
    app = Flask(__name__)
    CORS(app)  # Enable CORS for all routes
    app.register_blueprint(routes_bp)
    logger.info("Flask app and routes initialized.")
    return app
 
if __name__ == "__main__":
    app = create_app()
    logger.info("Starting Eat Safe API server...")
    app.run(host="0.0.0.0", port=5000, debug=True)
 
 