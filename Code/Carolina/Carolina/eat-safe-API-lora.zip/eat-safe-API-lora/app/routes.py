"""
Flask Routes for Eat Safe API
Defines the main endpoint for restaurant inspection and summary.
"""
from flask import Blueprint, request, jsonify
from app.services.inspections import search_inspections
from app.models.model import summarizer
from app.utils.logger import logger

bp = Blueprint('routes', __name__)

@bp.route('/api/restaurant-info', methods=['POST'])
def restaurant_info():
    """
    Receives a JSON payload with a 'query' field (restaurant name or address),
    fetches inspection data, runs the model, and returns summary and keywords.
    Example input: { "query": "Giordano's" }
    Returns: { "summary": ..., "keywords": [...] }
    """
    data = request.get_json()
    if not data or 'query' not in data:
        logger.warning("No query provided in request.")
        return jsonify({"error": "Missing 'query' in request body."}), 400

    query = data['query']
    logger.info(f"Received request for query: {query}")
    inspections = search_inspections(query, limit=1)
    if not inspections:
        logger.info(f"No inspection data found for query: {query}")
        return jsonify({"error": "No inspection data found for the provided query."}), 404

    # Use the most recent inspection's violations
    violations = inspections[0].get('violations', '')
    if not violations:
        logger.info(f"No violations found for query: {query}")
        return jsonify({"error": "No violations found for the provided query."}), 404

    result = summarizer.summarize_violation(violations)
    logger.info(f"Returning model result for query: {query}")
    return jsonify(result)
