"""
Chicago Health Inspections API Service
Provides functions to query the City of Chicago Health Inspections API.
"""
import os
from sodapy import Socrata
from dotenv import load_dotenv
from app.utils.logger import logger

# Load environment variables from .env file
load_dotenv()

CHICAGO_API_KEY = os.getenv("CHICAGO_API_KEY")

if not CHICAGO_API_KEY:
    logger.error("CHICAGO_API_KEY not found in environment variables.")

# Socrata dataset ID for Chicago Health Inspections
data_domain = "data.cityofchicago.org"
dataset_id = "4ijn-s7e5"

client = Socrata(data_domain, CHICAGO_API_KEY)

def search_inspections(query: str, limit: int = 10):
    """
    Search for restaurant inspections by name or address.
    Args:
        query (str): Restaurant name or part of the address.
        limit (int): Maximum number of results to return.
    Returns:
        list: List of inspection records (dicts).
    """
    logger.info(f"Searching inspections for query: {query}")
    where_clause = f"upper(dba_name) LIKE '%{query.upper()}%' OR upper(address) LIKE '%{query.upper()}%'"
    select_str = ",".join([
        "dba_name", "facility_type", "address", "city", "state", "zip",
        "inspection_date", "inspection_type", "risk", "results", "violations"
    ])
    try:
        results = client.get(
            dataset_id,
            where=where_clause,
            select=select_str,
            order="inspection_date DESC",
            limit=limit
        )
        logger.info(f"Found {len(results)} inspection records.")
        return results
    except Exception as e:
        logger.error(f"Error querying Chicago API: {e}")
        return []
