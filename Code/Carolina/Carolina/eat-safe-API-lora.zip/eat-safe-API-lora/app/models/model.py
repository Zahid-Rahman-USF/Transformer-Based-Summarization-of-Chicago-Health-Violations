"""
Model Loader and Inference Utilities for FLAN-T5
Loads the fine-tuned FLAN-T5 model and provides inference utilities.
"""
import os
from transformers import T5ForConditionalGeneration, AutoTokenizer
import torch
from app.utils.logger import logger

try:
    from peft import PeftModel, PeftConfig
    PEFT_AVAILABLE = True
except ImportError:
    PEFT_AVAILABLE = False
    logger.warning("peft library not found. Adapter weights will not be loaded.")

BASE_MODEL = "google/flan-t5-base"
ADAPTER_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../flan_t5_finetuned_final'))

class FlanT5Summarizer:
    """
    Loads the fine-tuned FLAN-T5 model and provides a method for summarization and keyword extraction.
    """
    def __init__(self, model_dir=ADAPTER_DIR, base_model=BASE_MODEL):
        logger.info(f"Loading FLAN-T5 base model: {base_model}")
        self.tokenizer = AutoTokenizer.from_pretrained(base_model)
        self.model = T5ForConditionalGeneration.from_pretrained(base_model)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        if PEFT_AVAILABLE and os.path.exists(os.path.join(model_dir, 'adapter_model.safetensors')):
            logger.info(f"Loading adapter weights from {model_dir}")
            self.model = PeftModel.from_pretrained(self.model, model_dir)
        else:
            logger.warning("Adapter weights not found or peft not available. Using base model only.")
        self.model = self.model.to(self.device)
        logger.info(f"Model loaded on device: {self.device}")

    def summarize_violation(self, text: str):
        """
        Generate a summary and keywords for a violation text.
        Args:
            text (str): The violation text to summarize.
        Returns:
            dict: { 'summary': str, 'keywords': list[str] }
        """
        instruction = (
            "Summarize this violation in one concise sentence (no boilerplate). "
            "Then list exactly the top 5 most important keywords. "
            "Format: Summary: ... Keywords: kw1, kw2, kw3, kw4, kw5"
        )
        prompt = instruction + "\n\nViolation:\n" + text
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, padding=True).to(self.device)
        with torch.no_grad():
            output = self.model.generate(**inputs, max_length=128)
        decoded = self.tokenizer.decode(output[0], skip_special_tokens=True)
        summary, keywords = self._parse_output(decoded)
        logger.info(f"Model inference complete. Summary: {summary}, Keywords: {keywords}")
        return {"summary": summary, "keywords": keywords}

    @staticmethod
    def _parse_output(raw: str):
        """
        Parse the model output into summary and keywords.
        Args:
            raw (str): Raw model output string.
        Returns:
            tuple: (summary, keywords_list)
        """
        parts = raw.split("Keywords:")
        summary = parts[0].replace("Summary:", "").strip().rstrip(".")
        kw_part = parts[1] if len(parts) > 1 else ""
        kws = [k.strip().lower().rstrip(".") for k in kw_part.split(",") if k.strip()]
        kws = (kws + [""]*5)[:5]  # Always return 5 slots
        return summary, kws

# Singleton instance to be loaded at app startup
summarizer = FlanT5Summarizer()
