
// Import necessary React hooks and components
import React, { useState, useCallback } from 'react';

// Import the API fetching function and the custom theme
import { fetchSafetyData } from './api';
import theme from './theme';

// Import Material UI components for building the user interface
import {
  Container,        // Main layout container
  TextField,        // Input field for search query
  Button,           // Search button
  Box,              // Generic container component for layout and styling
  Typography,       // Text elements (headings, paragraphs)
  CircularProgress, // Loading indicator
  Alert,            // Component for displaying error messages
  Chip,             // Used to display keywords
  CssBaseline,      // Provides consistent baseline styling across browsers
  ThemeProvider,    // Applies the custom theme to descendant components
  InputAdornment    // Used to add icons inside the TextField
} from '@mui/material';

// Import the Search icon from Material UI icons
import SearchIcon from '@mui/icons-material/Search';

// Define the background image URL
// Replace with the actual Unsplash URL or a locally hosted image path
const backgroundImageUrl = 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1974&auto=format&fit=crop'; // Example: A different restaurant interior

// --- Main Application Component ---

/**
 * The main functional component for the Eat Safe application.
 * It manages the application state (search query, results, loading status, errors)
 * and renders the user interface, including the search bar and results display area.
 */
function App() {
  // --- State Management using useState hook ---
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // --- Event Handlers ---
  const handleInputChange = (event) => {
    setQuery(event.target.value);
    if (results || error) {
        setResults(null);
        setError(null);
    }
  };

  const handleSearch = useCallback(async () => {
    if (!query.trim()) {
      setError('Please enter a search query.');
      setResults(null);
      return;
    }
    setLoading(true);
    setError(null);
    setResults(null);
    try {
      const data = await fetchSafetyData(query);
      setResults(data);
    } catch (err) {
      console.error('Search failed:', err);
      setError(err.message || 'Failed to fetch data. Please try again.');
      setResults(null);
    } finally {
      setLoading(false);
    }
  }, [query]);

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  };

  // --- Render Logic (JSX) ---
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {/* Outer Box to apply background image */}
      <Box sx={{
        minHeight: '100vh', // Ensure box takes at least full viewport height
        backgroundImage: `url(${backgroundImageUrl})`,
        backgroundSize: 'cover', // Cover the entire area
        backgroundPosition: 'center', // Center the image
        backgroundRepeat: 'no-repeat',
        display: 'flex', // Use flexbox to center content vertically
        alignItems: 'center', // Center content vertically
        py: 4, // Add some vertical padding
      }}>
        {/* Main content container */}
        {/* Removed maxWidth="md" to allow content to potentially stretch more */}
        {/* Added background color with opacity to make text readable over image */}
        <Container sx={{ backgroundColor: 'rgba(255, 255, 255, 0.1)', backdropFilter: 'blur(5px)', borderRadius: '16px', p: 4 }}>

          {/* Application Header - Adjusted color for better contrast */}
          <Typography variant="h4" component="h1" gutterBottom align="center" sx={{ color: 'white', textShadow: '1px 1px 3px rgba(0,0,0,0.7)', mb: 4 }}>
            Eat Safe: Restaurant Safety Check for Chicago
          </Typography>

          {/* Search Bar Area - Styled like the reference image */}
          <Box
            component="form"
            onSubmit={(e) => { e.preventDefault(); handleSearch(); }}
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              p: 3, // Padding inside the box
              mb: 4,
              width: '100%',
              maxWidth: '600px',
              mx: 'auto',
              backgroundColor: 'white', // White background for the search box
              borderRadius: '16px', // Modern rounded corners
              boxShadow: 3, // Subtle shadow for depth (theme shadow)
            }}
            noValidate
            autoComplete="off"
          >
            {/* Search Input Field */}
            <TextField
              fullWidth
              variant="outlined" // Use outlined for better look on white bg
              label="Search Restaurant Name or Address"
              value={query}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              disabled={loading}
              InputProps={{
                  startAdornment: (
                  <InputAdornment position="start">
                      <SearchIcon />
                  </InputAdornment>
                  ),
                  // Optional: Apply rounded corners directly if theme override isn't used
                  // sx: { borderRadius: '8px' }
              }}
              // Optional: Apply rounded corners directly if theme override isn't used
              // sx={{ '& .MuiOutlinedInput-root': { borderRadius: '8px' } }}
            />
            {/* Search Button */}
            <Button
              variant="contained"
              color="primary"
              onClick={handleSearch}
              disabled={loading || !query.trim()}
              sx={{
                  height: '56px',
                  borderRadius: '8px' // Consistent rounded corners
              }}
            >
              {loading ? <CircularProgress size={24} color="inherit" /> : 'Search'}
            </Button>
          </Box>

          {/* Results Display Area */}
          <Box sx={{ mt: 3 }}>
            {/* Loading Indicator */}
            {loading && (
              <Box sx={{ display: 'flex', justifyContent: 'center', my: 3 }}>
                <CircularProgress sx={{ color: 'white' }} /> {/* White spinner for contrast */}
              </Box>
            )}

            {/* Error Message - Styled for better visibility */}
            {error && (
              <Alert severity="error" sx={{ mb: 2, borderRadius: '8px' }}>
                {error}
              </Alert>
            )}

            {/* Results Display - Styled for better visibility */}
            {results && !loading && (
              <Box sx={{
                  p: 3,
                  // Kept original style but with rounded corners
                  border: '1px solid rgba(255, 255, 255, 0.3)', // Lighter border
                  borderRadius: '16px', // Rounded corners
                  backgroundColor: 'rgba(255, 255, 255, 0.85)', // Slightly transparent white
                  backdropFilter: 'blur(3px)', // Slight blur behind results
                  color: '#333' // Darker text color for readability on light bg
              }}>
                <Typography variant="h6" component="h2" gutterBottom>
                  Safety Summary
                </Typography>
                <Typography variant="body1" paragraph>
                  {results.summary}
                </Typography>
                {results.keywords && results.keywords.length > 0 && (
                  <>
                    <Typography variant="h6" component="h3" gutterBottom sx={{ mt: 2 }}>
                      Keywords
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {results.keywords.map((keyword, index) => (
                        <Chip
                          label={keyword}
                          key={index}
                          variant="outlined"
                          size="small"
                          // Optional: Adjust chip color if needed
                          // sx={{ borderColor: 'rgba(0, 0, 0, 0.23)', color: '#333' }}
                        />
                      ))}
                    </Box>
                  </>
                )}
              </Box>
            )}
          </Box>
        </Container>
      </Box>
    </ThemeProvider>
  );
}

export default App;
