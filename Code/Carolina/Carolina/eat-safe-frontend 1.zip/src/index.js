
import React from 'react';
import ReactDOM from 'react-dom/client';
// You might want a basic CSS reset or global styles
// import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
