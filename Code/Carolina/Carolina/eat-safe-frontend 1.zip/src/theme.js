
import { createTheme } from '@mui/material/styles';

/**
 * Defines the Material UI theme for the Eat Safe application.
 * Includes primary/secondary colors, typography settings, and component overrides.
 */
const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2', // Blue - Consider changing if it clashes with background
    },
    secondary: {
      main: '#dc004e', // Pink
    },
    background: {
        // Optional: Define a default background if needed, though App.js overrides it
        // default: '#f0f0f0'
    }
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
      marginBottom: '1rem',
    },
    body1: {
      lineHeight: 1.6,
    },
  },
  components: {
    MuiChip: {
      styleOverrides: {
        root: {
          margin: '4px',
        },
      },
    },
    // Optional: Define default rounded corners for buttons
    MuiButton: {
        styleOverrides: {
            root: {
                borderRadius: '8px', // Example: slightly more rounded buttons by default
            }
        }
    },
    // Optional: Define default rounded corners for text fields
    MuiOutlinedInput: {
        styleOverrides: {
            root: {
                borderRadius: '8px', // Example: slightly more rounded text fields
            }
        }
    }
  },
});

export default theme;
