// Import the Axios library for making HTTP requests
import axios from 'axios';

// --- Configuration Constants ---

// API_URL: Backend endpoint that accepts a JSON body { query: "<search term>" }.
// IMPORTANT: Replace the placeholder URL with your production endpoint.
const API_URL = 'http://localhost:5000';

// USE_DUMMY_API: Toggle between simulated data and real HTTP requests.
const USE_DUMMY_API = false;

// --- Dummy API Simulation Function ---

/**
 * Simulates fetching data from an API endpoint (development only).
 *
 * @param {string} query - The search term entered by the user.
 * @returns {Promise<{ summary: string, keywords: string[] }>}
 */
const fetchDummyData = (query) => {
  console.log(`Simulating API call for query: ${query}`);

  return new Promise((resolve) => {
    setTimeout(() => {
      let summary = `This is a sample summary for "${query}". It provides safety information based on mock data.`;
      let keywords = ['mock data', 'safe', 'restaurant', query.toLowerCase()];

      if (query.toLowerCase().includes('pizza')) {
        summary = `Detailed safety report for pizza places matching "${query}". Found potential hygiene concerns in mock data.`;
        keywords = ['pizza', 'hygiene concern', 'mock data', 'warning'];
      } else if (query.toLowerCase().includes('taco')) {
        summary = `Safety analysis for taco vendors related to "${query}". Mock data indicates good standing.`;
        keywords = ['taco', 'good standing', 'safe', 'mock data'];
      }

      resolve({ summary, keywords });
    }, 1500);
  });
};

// --- Main Data-Fetching Function ---

/**
 * Fetches restaurant-safety data for the provided query.
 *
 * @param {string} query - Restaurant name or address fragment.
 * @returns {Promise<{ summary: string, keywords: string[] }>}
 */
export const fetchSafetyData = async (query) => {
  if (USE_DUMMY_API) {
    // ----- Use Dummy Stub -----
    return fetchDummyData(query);
  }

  // ----- Use Real API (POST JSON) -----
  console.log(`Posting to real API: ${API_URL}`);

  try {
    const response = await axios.post(
      API_URL + "/api/restaurant-info",
      { query },                                 // request body
      { headers: { 'Content-Type': 'application/json' } }
    );

    // Basic shape validation
    if (
      response.data &&
      typeof response.data.summary === 'string' &&
      Array.isArray(response.data.keywords)
    ) {
      return response.data;
    } else {
      console.error('Invalid API response format:', response.data);
      throw new Error('Received invalid data format from the server.');
    }
  } catch (error) {
    console.error('Axios request failed:', error);

    if (error.response) {
      throw new Error(
        `API Error: ${error.response.status} - ${
          error.response.data?.message || error.response.statusText
        }`
      );
    } else if (error.request) {
      throw new Error('Network Error: No response received from server.');
    } else {
      throw new Error(`Request Setup Error: ${error.message}`);
    }
  }
};