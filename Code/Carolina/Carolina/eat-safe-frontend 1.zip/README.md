
# Eat Safe: Frontend Web Application (Refactored)

This document provides an overview and setup instructions for the refactored Eat Safe frontend React application.

## 1. Overview

Eat Safe allows users to search for restaurant safety information. This version is structured with separate files for API logic, theme configuration, and the main application component. It uses React, Material UI, and Axios.

## 2. Project Structure

```
eat-safe-frontend/
├── public/
│   └── index.html
├── src/
│   ├── api.js
│   ├── theme.js
│   ├── App.js
│   ├── index.js
│   └── index.css (Optional)
├── package.json
├── README.md
└── .gitignore (Recommended)
```

## 3. Key Files

-   **`src/theme.js`**: Exports the Material UI theme object.
-   **`src/api.js`**: Handles API calls (Axios) and dummy data simulation. Contains configuration constants `API_URL_TEMPLATE` and `USE_DUMMY_API`.
-   **`src/App.js`**: Main application component, manages state and renders UI.
-   **`src/index.js`**: Entry point, renders the App component.
-   **`package.json`**: Defines dependencies and scripts.

## 4. Setup and Running

1.  **Prerequisites**: Node.js and npm installed.
2.  **Installation**: Run `npm install` in the project root directory.
3.  **Configuration (Optional)**: Edit `src/api.js` to set `USE_DUMMY_API` to `false` and update `API_URL_TEMPLATE` if connecting to a real backend.
4.  **Run**: Run `npm start` to launch the development server (usually at http://localhost:3000).

## 5. Building for Production

Run `npm run build` to create an optimized build in the `build/` folder.
